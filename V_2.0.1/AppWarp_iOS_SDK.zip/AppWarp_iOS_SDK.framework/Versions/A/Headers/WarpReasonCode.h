//
//  WarpReasonCode.h
//  AppWarp_Project
//
//  Created by Shephertz Technologies Pvt Ltd on 03/09/14.
//  Copyright (c) 2014 ShephertzTechnology PVT LTD. All rights reserved.
//

#ifndef AppWarp_Project_WarpReasonCode_h
#define AppWarp_Project_WarpReasonCode_h

static const int WAITING_FOR_PAUSED_USER = 21;
static const int INVALID_API_KEY = 22;
#endif