//
//  TurnBasedRoomListener.h
//  AppWarp_Project
//
//  Created by shephertz technologies on 24/07/13.
//  Copyright (c) 2013 ShephertzTechnology PVT LTD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MoveEvent.h"

@protocol TurnBasedRoomListener <NSObject>
@required

/**
 * Invoked when a room is created. Lobby subscribers will receive this.
 * @param event
 */
-(void)onSendMoveDone:(Byte)result;
    
-(void)onStartGameDone:(Byte)result;

-(void)onStopGameDone:(Byte)result;

-(void)onGetMoveHistoryDone:(Byte)result moves:(NSMutableArray*)movesArray;

@end
